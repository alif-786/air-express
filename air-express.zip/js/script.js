const themeBtn = document.getElementById("theme-btn");
const body = document.body;

themeBtn.addEventListener("click", () => {
    body.classList.toggle("dark");
    body.classList.toggle("light");
    console.log("button clicked");

    const themeIcon = document.querySelector(".theme-icon");
    themeIcon.classList.toggle("fa-solid");

    const theme = body.classList.contains("dark") ? "dark" : "light";
    localStorage.setItem("theme", theme);
});

const userTheme = localStorage.getItem("theme");

if (userTheme === "dark") {
    body.classList.add("dark");
    document.querySelector(".theme-icon").classList.add("dark");
} else {
    body.classList.add("light");
}





// Submit form event listener


const toastTrigger = document.getElementById('liveToastBtn');
const toastLiveExample = document.getElementById('liveToast');
const contactForm = document.getElementById('contactForm');

if (toastTrigger) {
    const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
    toastTrigger.addEventListener('click', (event) => {
        event.preventDefault();
        if (contactForm.checkValidity()) {
            toastBootstrap.show();
            contactForm = ""
        }
        contactForm.classList.add('was-validated');
    });
}
// modal2
const toastTrigger2 = document.getElementById('liveToastBtn2');
const toastLiveExample2 = document.getElementById('liveToast');
const contactForm2 = document.getElementById('contactForm');

if (toastTrigger2) {
    const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
    toastTrigger2.addEventListener('click', (event) => {
        event.preventDefault();
        if (contactForm2.checkValidity()) {
            toastBootstrap.show();
            contactForm2 = ""
        }
        contactForm2.classList.add('was-validated');
    });
}
// modal2
const toatTrigger3 = document.getElementById('liveToastBtn2');
const toastLiveExample3 = document.getElementById('liveToast');
const contactForm3 = document.getElementById('contactForm');

if (toatTrigger3) {
    const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
    toatTrigger3.addEventListener('click', (event) => {
        event.preventDefault();
        if (contactForm3.checkValidity()) {
            toastBootstrap.show();
            contactForm3 = ""
        }
        contactForm3.classList.add('was-validated');
    });
}
